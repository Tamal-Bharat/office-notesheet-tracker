const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const {NoteSheetModel} = require('./databases/dbnotesheetModel');

const app = express();
const PORT = process.env.PORT || 3032;
const HOST = '192.168.29.96';

app.use(cors({origin: ['http://localhost:3000']}));
app.use(bodyParser.urlencoded({extended: true}));
app.use(bodyParser.json());


//API for saving a single notesheet record
app.post('/savenotesheet', (req, res)=>{

    const notesheet = new NoteSheetModel({
        cccname: req.body.cccname,
        noteid: req.body.noteid,
        note_date: req.body.note_date,
        notedesc: req.body.notedesc,
        received: req.body.note_received,
        forwarded: req.body.note_forwarded,
        remarks: req.body.note_remarks
    });

    notesheet.save()
        .then((response)=>{
            console.log(`Note added successfully`);
            res.status(200).send(response);
        })
        .catch((err)=>{
            console.log(`Note save error occured: ${err}`);
            res.status(404).send(err);
        });

    //res.status(200).send(req.body);
});

//API for getting notesheet records
app.get('/getnotesheets', (req, res)=>{

    NoteSheetModel.find({noteid: {$regex: req.query.noteid, $options: 'i'}})
                    .then((response)=>{
                        console.log(response);
                        res.status(200).send(response);
                    })
                    .catch((err)=>{
                        console.log(err);
                        res.status(404).send(err);
                    })
    
});

app.get('/getallnotesheets', (req, res)=>{

    NoteSheetModel.find({})
                    .then((response)=>{
                        res.status(200).send(response);
                    })
                    .catch((error)=>{
                        res.status(404).send(error)
                    })

});

app.listen(PORT, HOST, (error)=>{
    console.log(`Application started at port: ${PORT}`);
});





