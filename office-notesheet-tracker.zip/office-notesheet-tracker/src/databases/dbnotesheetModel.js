const {mongoose} = require('./dbconnection');

    const NoteSheetSchema = mongoose.Schema;

    const noteSheetSchemaDataType = new NoteSheetSchema({
        cccname: {type: String},
        noteid: {type: String},
        note_date: {type: String},
        notedesc: {type: String},
        received: {type: String}, 
        forwarded: {type: String},
        remarks: {type: String}
    });

    const NoteSheetModel = mongoose.model('NoteSheet', noteSheetSchemaDataType);

module.exports = {NoteSheetModel};



     



